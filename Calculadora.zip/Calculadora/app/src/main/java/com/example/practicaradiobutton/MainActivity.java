package com.example.practicaradiobutton;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText num1;
    private EditText num2;
    private RadioButton rad_sumar;
    private RadioButton rad_multi;
    private RadioButton rad_dividir;
    private RadioButton rad_restar;
    private Button but_calcular;
    private TextView text_resultado;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        num1 = findViewById(R.id.num1);
        num2 = findViewById(R.id.num2);
        rad_sumar = findViewById(R.id.rad_sumar);
        rad_multi = findViewById(R.id.rad_multi);
        rad_dividir = findViewById(R.id.rad_dividir);
        rad_restar = findViewById(R.id.rad_restar);
        but_calcular = findViewById(R.id.but_calcular);
        text_resultado = findViewById(R.id.text_resultado);
    }

    public void calcularOperacion(View v){
        String textonumero1=num1.getText().toString();
        float numero1=Float.parseFloat(textonumero1);
        String textonumero2=num2.getText().toString();
        float numero2=Float.parseFloat(textonumero2);
        float resultado=0;

        if(rad_sumar.isChecked()){
            resultado=numero1+numero2;
        }else if(rad_multi.isChecked()){
            resultado=numero1*numero2;
        }else if(rad_dividir.isChecked()){
            resultado=numero1/numero2;

        }else if(rad_restar.isChecked()){
            resultado=numero1-numero2;

        }
        text_resultado.setText(String.valueOf(resultado));
    }
}